#citire
ora=input()
ora=ora.split(':')
h=100*int(ora[0])+int(ora[1]) #creem ora ca fiind HHMM
n=int(input())
i=0
filme=[]
NrFilme=0
while i<n:
    film=input()
    film=film.split()
    ora.clear()
    ora=film[0]
    ora=ora.split(':')
    h1=100*int(ora[0])+int(ora[1])
    if h1<h:
        pass #ignoram filmele dinaintea orei la care ajungem
    else: # altfel le memoram
        NrFilme+=1
        film[0]=h1
        filme.append(film)
    i+=1

#prelucrare
i=0
ore=[]
while i<NrFilme:
    ore.append(filme[i][0]) #vedem cat dureaza fiecare film
    i+=1
OraMin=min(ore) #aflam filmul care incepe cel mai devreme
filmales='niciunul'
pret=999
i=0
while i<NrFilme: #cautam filmul cu cel mai mic pret daca incep la aceasi ora
    if int(filme[i][0])==int(OraMin) and int(filme[i][1])<int(pret):
        pret=filme[i][1]
        filmales=filme[i][2]
    i+=1

#afisare
print(filmales)